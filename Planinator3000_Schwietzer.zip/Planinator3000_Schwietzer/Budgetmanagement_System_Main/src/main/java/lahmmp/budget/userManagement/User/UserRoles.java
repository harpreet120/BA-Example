package lahmmp.budget.userManagement.User;

public enum UserRoles {
    ADMINISTRATOR,
    MANAGEMENT,
    OWNER,
}
